let pretragaDugme = document.querySelector('#pretraga-dugme');
let pretragaBar = document.querySelector('.pretraga-bar-kontejner');
let formaDugme = document.querySelector('#login-dugme');
let loginForma = document.querySelector('.login-forma-kontejner');
let formaZatvaranje = document.querySelector('#forma-zatvaranje');
let meni = document.querySelector('#meni-bar');
let navigacioniBar = document.querySelector('.navigacioni-bar');
let videoDugme = document.querySelectorAll('.video-dugme');

window.onscroll = () =>{
    meni.classList.remove('fa-times');
    navigacioniBar.classList.remove('active');
    loginForma.classList.remove('active');
}

meni.addEventListener('click', () =>{
    meni.classList.toggle('fa-times');
    navigacioniBar.classList.toggle('active');
});

pretragaDugme.addEventListener('click', () =>{
    pretragaDugme.classList.toggle('fa-times');
    pretragaBar.classList.toggle('active');
});

formaDugme.addEventListener('click', () =>{
    loginForma.classList.add('active');
});

formaZatvaranje.addEventListener('click', () =>{
    loginForma.classList.remove('active');
});

videoDugme.forEach(btn =>{
    btn.addEventListener('click', ()=>{
        document.querySelector('.kontrole .active').classList.remove('active');
        btn.classList.add('active');
        let src = btn.getAttribute('data-src');
        document.querySelector('#video-slajder').src = src;
    });
});

//Opcije za swiper
var swiper = new Swiper(".recenzije-slajder", {
    spaceBetween: 20,
    loop:true,
    autoplay: {
        delay: 2500,
        disableOnInteraction: false,
    },
    breakpoints: {
        640: {
          slidesPerView: 1,
        },
        768: {
          slidesPerView: 2,
        },
        1024: {
          slidesPerView: 3,
        },
    },
});

var swiper = new Swiper(".sponzori-slajder", {
    spaceBetween: 20,
    loop:true,
    autoplay: {
        delay: 2500,
        disableOnInteraction: false,
    },
    breakpoints: {
        450: {
          slidesPerView: 2,
        },
        768: {
          slidesPerView: 3,
        },
        991: {
          slidesPerView: 4,
        },
        1200: {
          slidesPerView: 5,
        },
      },
});


//Validacija za login
document.getElementById("ulogujSe").onclick = function(){
  let email = document.getElementById("email").value;
  let sifra = document.getElementById("sifra").value;

  if (email.indexOf("@") > -1 && sifra){
     alert("Uspesno ste se ulogovali.");
    location.reload();
  }

   else if (email.indexOf("@") == -1 && sifra){
     alert("Email polje nije popunjeno ili ne odgovara format.");
   }

   else {
    alert("Polja nisu popunjena.");
   }
}






//Funkcija za cuvanje vrednosti pozadinske boje u cookie
var button = document.getElementById("tamnaTema");

button.addEventListener("click", function() {
  var elements = document.getElementsByTagName("body");
  for (var i = 0; i < elements.length; i++) {
    elements[i].style.backgroundColor = "#111";
  }
  document.cookie = "backgroundColor=#111";
});

if (document.cookie.indexOf("backgroundColor") >= 0) {
  var backgroundColor = document.cookie.split("=")[1];
  var elements = document.getElementsByTagName("body");
  for (var i = 0; i < elements.length; i++) {
    elements[i].style.backgroundColor = backgroundColor;
  }
}

var button2 = document.getElementById("svetlaTema");

button2.addEventListener("click", function() {
  var elements = document.getElementsByTagName("body");
  for (var i = 0; i < elements.length; i++) {
    elements[i].style.backgroundColor = "#fff";
  }
  document.cookie = "backgroundColor=#fff";
});

if (document.cookie.indexOf("backgroundColor") >= 0) {
  var backgroundColor = document.cookie.split("=")[1];
  var elements = document.getElementsByTagName("body");
  for (var i = 0; i < elements.length; i++) {
    elements[i].style.backgroundColor = backgroundColor;
  }
}

//Popunjavanje tabele iz JSON fajla
$(document).ready(function() {
  $.ajax({
      url: 'podaci.json',
      dataType: 'json',
      success: function(data) {

          var tableBody = $('#tabelaZaposlenih tbody');

          $.each(data, function(key, value) {
              var row = $('<tr>');
              $('<td>').text(value.ime).appendTo(row);
              $('<td>').text(value.prezime).appendTo(row);
              $('<td>').text(value.struka).appendTo(row);
              row.appendTo(tableBody);
          });
      }
  });
});
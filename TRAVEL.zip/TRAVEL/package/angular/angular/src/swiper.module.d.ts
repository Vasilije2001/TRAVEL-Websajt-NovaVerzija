export declare class SwiperModule {
}

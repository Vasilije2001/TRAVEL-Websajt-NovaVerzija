/**
 * Swiper 6.6.2
 * Most modern mobile touch slider and framework with hardware accelerated transitions
 * https://swiperjs.com
 *
 * Copyright 2014-2021 Vladimir Kharlampidi
 *
 * Released under the MIT License
 *
 * Released on: May 19, 2021
 */

"use strict";
exports.__esModule = true;
exports.default = require('./cjs/components/core/core-class').default;
exports.Swiper = require('./cjs/components/core/core-class').default;
exports.Virtual = require('./cjs/components/virtual/virtual').default;
exports.Keyboard = require('./cjs/components/keyboard/keyboard').default;
exports.Mousewheel = require('./cjs/components/mousewheel/mousewheel').default;
exports.Navigation = require('./cjs/components/navigation/navigation').default;
exports.Pagination = require('./cjs/components/pagination/pagination').default;
exports.Scrollbar = require('./cjs/components/scrollbar/scrollbar').default;
exports.Parallax = require('./cjs/components/parallax/parallax').default;
exports.Zoom = require('./cjs/components/zoom/zoom').default;
exports.Lazy = require('./cjs/components/lazy/lazy').default;
exports.Controller = require('./cjs/components/controller/controller').default;
exports.A11y = require('./cjs/components/a11y/a11y').default;
exports.History = require('./cjs/components/history/history').default;
exports.HashNavigation = require('./cjs/components/hash-navigation/hash-navigation').default;
exports.Autoplay = require('./cjs/components/autoplay/autoplay').default;
exports.EffectFade = require('./cjs/components/effect-fade/effect-fade').default;
exports.EffectCube = require('./cjs/components/effect-cube/effect-cube').default;
exports.EffectFlip = require('./cjs/components/effect-flip/effect-flip').default;
exports.EffectCoverflow = require('./cjs/components/effect-coverflow/effect-coverflow').default;
exports.Thumbs = require('./cjs/components/thumbs/thumbs').default;